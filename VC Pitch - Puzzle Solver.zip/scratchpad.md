# VC Pitch — Logic-Grid Puzzle Solver

**Audience:** the VC who funded + wrote the spec. Back from safari (leopard print), busy — 8 min talk + 2 min Q&A.
**Presenters:** Abhijai (product/spec/trust half) + Bhavay (composition deep dive).
**Goals:** (1) prove the app is built faithfully to SPECS.md; (2) be transparent about forced assumptions; (3) climax = composition-over-inheritance with REAL code snippets.

**Aesthetic:** editorial VC pitch — warm paper, near-black ink, single emerald accent (the app's "Solved" green), Newsreader display serif + Hanken Grotesk body + JetBrains Mono code on dark code cards. Lots of whitespace. One tasteful safari/leopard wink at the section divider.

## Title sequence (clean parallel topic titles — NO "not X, but Y" trope in titles)
1. (cover)  Logic-Grid Puzzle Solver
2. The brief
3. Built to the spec
4. Where the spec was silent   ← assumptions, incl. budget/Sonnet now resolved
5. The solver in action          ← real screenshot proof
6. The solving pipeline          ← diagram: validate → CNF → SAT → classify → explain
7. Three kinds of answer         ← unique / under-constrained / over-constrained (MUS)
8. Human-readable deductions     ← the novelty: SAT-as-oracle, cited steps
9. Natural-language clues        ← LLM layer, confirm-before-add, now on spec Sonnet
10. (section) Composition over Inheritance   ← the principle "from the safari"
11. The principle, and where we applied it   ← the bet + 4 seams
12. Clues as data and handlers   ← C1 handler object snippet
13. The handler registry         ← one lookup table replaces virtual dispatch
14. Inference rules as strategy objects   ← makePropagationRule: R3/R4/R5 = one fn
15. The SAT solver boundary      ← inject interface, default MiniSat
16. Honest trade-offs            ← classes used by composition; cost = indirection
17. Where we stand               ← status, tests/coverage, Q&A

Reading the titles alone tells the story: brief → spec fidelity → honest assumptions → working app → how it works → the principle he asked for, applied in real code → honest trade-offs → status.

## Key facts (grounded)
- App: define logic-grid (Einstein/zebra) puzzles, solve via SAT, EXPLAIN step-by-step like a human.
- Stack: React+TS+Vite, Tailwind+shadcn, Zustand, logic-solver (MiniSat WASM) in Web Worker, Express LLM proxy. Vitest + Playwright. ~102 tests, ~93.8% core coverage.
- 9 clue types (C1–C9). Structured + NL input. 3 outcomes: unique / under (2 solns + ambiguous cells) / over (MUS).
- Deduction chain: forward-chaining engine, R1–R6 rules, SAT answer used as ORACLE to pick correct branch (no visible backtracking).

## Assumptions (slide 4) — where SPECS.md was silent/ambiguous
- **X ≠ Y self-reference**: spec contradicts itself ("different categories" vs "different cells"). Decisive: the MANDATORY zebra example needs same-category clue (green house immediately left of white). → bound as different CELLS. (best one — shows careful reading)
- **n upper bound**: [3,8] hard bound vs n=6 perf target → enforce [3,8], treat n=6 as guidance.
- **LLM model / budget**: spec wants Anthropic Sonnet. Initially used budget model (claude-3.5-haiku via OpenRouter) under tight budget. → NOW RESOLVED: budget available, running spec-mandated Sonnet. No longer a deviation.
- **SAT package**: spec names minisat.js; used logic-solver (same MiniSat core, functionally equivalent).
- **Zebra ~60 steps vs ≤30 target**: faithful per-placement R2 steps; all correct + cited; verbosity tuning is a follow-up (known §11 risk).

## Composition-over-inheritance code snippets (all verified against source)
1. handlers.ts:55-67 — C1 handler object (data + functions, no Clue base class)
2. registry.ts:13-24 — REGISTRY map + getClueHandler (the seam replacing virtual dispatch)
3. engine.ts:178-196 + 288-295 — makePropagationRule + RULES array (R3/R4/R5 one fn, delegate to handler.relation)
4. sat.ts:30-32,80-84 + pipeline.ts:51-54 — SatSolver interface + injected default miniSatSolver
